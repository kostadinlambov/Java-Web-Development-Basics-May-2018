package org.softuni.fdmc.util;

public enum Type  {
    FOOD, DOMESTIC, HEALTH, COSMETIC, OTHER
}
