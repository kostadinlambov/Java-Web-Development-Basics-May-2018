package main.entities;

public enum Role {
    USER,
    ADMIN
}
