package main.repositories.util;

public interface RepositoryActionInvoker {
    void invoke(RepositoryActionResult repositoryActionResult);
}
