package main.repositories.util;

public interface RepositoryActionResult {
    Object getResult();

    void setResult(Object result);
}
