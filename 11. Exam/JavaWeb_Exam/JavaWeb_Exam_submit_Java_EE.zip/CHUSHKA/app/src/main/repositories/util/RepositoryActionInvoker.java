package repositories.util;

public interface RepositoryActionInvoker {
    void invoke(RepositoryActionResult repositoryActionResult);
}
