package entities;

public enum ProductType {
    FOOD,
    DOMESTIC,
    HEALTH,
    COSMETIC,
    OTHER
}
